package evals;

public class Sum {
	public int doCalc() {
		return 10;
	}

	public int doAnotherCalc() {
		return 20;
	}

}
