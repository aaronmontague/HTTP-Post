package evals;

public class Pet {
	// Attributes
	int weight;
	String color;
	
	// Constructors
	public Pet() {}
	public Pet(int petWeight, String petColor) {
		this.weight = petWeight;
		this.color = petColor;
	}
	
	// Methods

}
