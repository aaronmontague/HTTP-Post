package evals;

public class Module3 {

	public static void main(String[] args) {
		Sum s = new BigSum();
		System.out.println(s.doCalc());
		
		// Dog constructor with super(int, String)
		Dog molly = new Dog(45, "Molly", "Fox Hound");
	}

}
