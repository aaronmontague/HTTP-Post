package polymorphism;

public class Mammal extends Animal {
	// Attributes

	// Constructors

	// Methods
	public void eat() {
		System.out.println("I eat everything");
	}

}
