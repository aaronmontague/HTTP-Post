import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BigRandom {

	public static void main(String[] args) {
		// create instance of Random class 
        Random rand = new Random();
        
		// Create between 200k and 240k lines
		int numberLines = rand.nextInt(40000);
		numberLines += 200000;
		
		// Set up Filewriter
		try {
			FileWriter fileWriter = new FileWriter("C:\\Users\\amonta01\\Desktop\\BigRandom.txt");
		    PrintWriter printWriter = new PrintWriter(fileWriter);
			
			for (int lines = 0; lines < numberLines; lines++) {
				// Create between 1 and 100 characters of text on each line
				int numberChars = rand.nextInt(99) + 1;
				// Print Line Number
				printWriter.print(lines + " - ");
				for (int chars = 0; chars < numberChars; chars++) {
					// Write to .txt file on desktop
					printWriter.print("c");
				}
				// Print New Line char
				printWriter.println();
			}
			System.out.println(numberLines);
			printWriter.close();
		}
		catch (Exception e) {
			System.out.println("That didn't work:");
			System.out.print(e.toString());
		}
	
	}

}
