
public class StringCompare {
	public static Boolean CompareTwoString(String s1, String s2)
	{
		return s1.equals(s2);
		//return s1 == s2;
	}

	public static Boolean CompareTwoStringWithStrip(String s1, String s2)
	{
		// Change to lower case
		String s1ToLower = s1.toLowerCase();
		String s2ToLower = s2.toLowerCase();
		
		// Strip out non alphanumerics
		String s1Temp = s1ToLower.replaceAll("[^a-zA-Z0-9]","");
		String s2Temp = s2ToLower.replaceAll("[^a-zA-Z0-9]","");
		
		// Compare again and return
		return s1Temp.equals(s2Temp);
	}
}
