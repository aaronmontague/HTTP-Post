
public class EasyString {

	public static void main(String[] args){
		String dog = "dog";
		String cat = "cat";
		String dogUnder = "dog_";
		String catUnder = "cat_";
		String dogUpper = "DOG";
		String catUpper = "CAT";
		String dogStar = "dog*";
		String catStar = "cat*";
		String starCatStar = "*cat*";
		String underCatStar = "_cat*";
		
		System.out.println("Compares without Stripping");
		System.out.printf("cat, cat: %s%n", StringCompare.CompareTwoString(cat, cat));
		System.out.printf("dog, cat: %s%n", StringCompare.CompareTwoString(dog, cat));
		System.out.printf("dogUnder, dogUnder: %s%n", StringCompare.CompareTwoString(dogUnder, dogUnder));
		System.out.printf("dogUnder, catUnder: %s%n", StringCompare.CompareTwoString(dogUnder, catUnder));
		
		System.out.println("Compares with Stripping");
		System.out.printf("dog, dog: %s%n", StringCompare.CompareTwoStringWithStrip(dog, dog));
		System.out.printf("dogUpper, dogUpper: %s%n", StringCompare.CompareTwoStringWithStrip(dogUpper, dogUpper));
		System.out.printf("dog, dogUpper: %s%n", StringCompare.CompareTwoStringWithStrip(dog, dogUpper));
		System.out.printf("catUnder, catUpper: %s%n", StringCompare.CompareTwoStringWithStrip(catUnder, catUpper));
		System.out.printf("catStar, catUpper: %s%n", StringCompare.CompareTwoStringWithStrip(catStar, catUpper));
		System.out.printf("starCatStar, underCatStar: %s%n", StringCompare.CompareTwoStringWithStrip(starCatStar, underCatStar));
		System.out.printf("cat, underCatStar: %s%n", StringCompare.CompareTwoStringWithStrip(cat, underCatStar));
		System.out.printf("dog, underCatStar: %s%n", StringCompare.CompareTwoStringWithStrip(dog, underCatStar));
		System.out.printf("dogStar, underCatStar: %s%n", StringCompare.CompareTwoStringWithStrip(dogStar, underCatStar));
		
		
		
	}

}
