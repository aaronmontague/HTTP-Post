package primary;

import java.util.*;

public class ListManipMain {

	public static void main(String[] args) {
		List<Person> currentEmployees = new ArrayList<Person>();
		
		currentEmployees.add(new Person("Aaron", "Montague", 32));
		currentEmployees.add(new Person("John", "Shea", 60));
		currentEmployees.add(new Person("Amy", "Lynn", 28));
		currentEmployees.add(new Person("Debbie", "Zacks", 55));
		
		// List all
		for (Person employee : currentEmployees) {
			System.out.println("First: " + employee.getFirstName() + " Id: " + employee.getId());
		}
		
		// Find employee to remove and remove
		int retiredEmployee = -1;
		for (Person employee : currentEmployees) {
			if (employee.getFirstName().equals("Debbie"))
			{
				retiredEmployee = currentEmployees.indexOf(employee);
			}
		}
		
		// If the employee was found, remove the employee
		if (retiredEmployee != -1)
		{
			currentEmployees.remove(retiredEmployee);
		}
		
		// List all after removal
		System.out.println();
		for (Person employee : currentEmployees) {
			System.out.println("First: " + employee.getFirstName() + " Id: " + employee.getId());
		}
		
	}
}