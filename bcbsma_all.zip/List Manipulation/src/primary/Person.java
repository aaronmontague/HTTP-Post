package primary;

import java.util.Random;

public class Person
{
	// Attributes
	private int id;
	private String firstName;
	private String lastName;
	private int age;
	
	// Constructors
	public Person() {}
	public Person(String fn, String ln, int a) {
		Random rand = new Random();
		id = rand.nextInt(10000);
		firstName = fn;
		lastName = ln;
		age = a;
	}
	
	// Methods
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}	
}