import java.time.*;
import java.util.*;

public class Utility {
	public static List<Hotel> createHotels()
	{
		List<Hotel> newHotelList = new ArrayList<Hotel>();
		// Link Reservations to Hotel
		List<Integer> resList1 = new ArrayList<Integer>();
		resList1.add(1);
		resList1.add(2);
		List<Integer> resList2 = new ArrayList<Integer>();
		resList2.add(3);
		List<Integer> resList3 = new ArrayList<Integer>();
		resList3.add(4);
		List<Integer> resList4 = new ArrayList<Integer>();
		resList4.add(5);
		
		// Create Hotels
		newHotelList.add(new Hotel(1, "Royal Sonesta Boston", "MA", true, resList1));
		newHotelList.add(new Hotel(2, "Garden Suites", "NY", false, resList2));
		newHotelList.add(new Hotel(3, "Royal Sonesta New York", "NY", true, resList3));
		newHotelList.add(new Hotel(4, "Anchors Away Inn", "RI", true, resList4));
		
		return newHotelList;
	}

	public static List<Reservation> createReservations()
	{
		// Create reservations
		Reservation res1 = new Reservation(1, 
				LocalDateTime.of(2019, Month.JUNE, 18, 0, 0), 
				LocalDateTime.of(2019, Month.JUNE, 21, 0, 0), 
				330.00, 
				1234);
		Reservation res2 = new Reservation(2, 
				LocalDateTime.of(2019, Month.JUNE, 9, 0, 0), 
				LocalDateTime.of(2019, Month.JUNE, 11, 0, 0), 
				287.52, 
				5678);
		Reservation res3 = new Reservation(3, 
				LocalDateTime.of(2019, Month.JUNE, 13, 0, 0), 
				LocalDateTime.of(2019, Month.JUNE, 14, 0, 0), 
				79.99, 
				5678);
		Reservation res4 = new Reservation(4, 
				LocalDateTime.of(2019, Month.JUNE, 3, 0, 0), 
				LocalDateTime.of(2019, Month.JUNE, 9, 0, 0), 
				1070.99, 
				8912);
		Reservation res5 = new Reservation(5, 
				LocalDateTime.of(2019, Month.JUNE, 12, 0, 0), 
				LocalDateTime.of(2019, Month.JUNE, 16, 0, 0), 
				530.00, 
				8912);
		// Add reservations to list
		List<Reservation> newReservationList = new ArrayList<Reservation>();
		newReservationList.add(res1);
		newReservationList.add(res2);
		newReservationList.add(res3);
		newReservationList.add(res4);
		newReservationList.add(res5);
		
		return newReservationList;
	}
}
