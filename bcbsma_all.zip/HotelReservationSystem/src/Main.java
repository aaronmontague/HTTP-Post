import java.util.List;

public class Main {

	public static void main(String[] args) {
		// This is your "database"
		// Load Hotels for Later Consumption
		List<Hotel> currentHotels = Utility.createHotels();
		
		// Load Reservations for all Hotels
		List<Reservation> allHotelReservations = Utility.createReservations();
		
		// Print out Hotel Details with Reservations Attached
		for (Hotel hotel : currentHotels) {
			System.out.printf("Name: %s \n"
					+ "State: %s\n"
					+ "Current Reservations:\n", 
					hotel.name, hotel.physicalBuildingState);
			// Loop through this hotel's reservations
			for (int resNumber : hotel.currentReservations) {
				// Find each reservation in All Reservations that match the id
				Reservation res = allHotelReservations.stream()
						.filter(thisReservation -> thisReservation.id == resNumber)
						.findAny()
						.orElse(null);
				System.out.printf("   Client: %s\n", res.customerAccountCharged);
				System.out.printf("   Staying: %1$tB %1$td, %1$tY - %2$tB %2$td, %2$tY\n", res.stayStartDate, res.stayEndDate);
				System.out.printf("   Total Charges: $%s\n", res.stayAmountChargedToCustomer);
			}
		}

	}
}
