import java.util.List;

public class Hotel {
	// Variables
	public int id;
	public String name;
	public String physicalBuildingState;
	public String businessState;
	public Boolean hasPool;
	public List<Integer> currentReservations;
	
	// Constructors
	public Hotel () {}
	public Hotel (int i, String n, String oneState, Boolean pool, List<Integer> resList) {
		name = n;
		physicalBuildingState = oneState;
		businessState = oneState;
		hasPool = pool;
		currentReservations = resList;
	}
	
	// Methods
	public void addReservation(int resNumber)
	{
		this.currentReservations.add(resNumber);
	}
}
