
public class CustomerAccount {
	// Variables
	public int id;
	public String name;
	public String userName;
	public String passWord;
	
	
	// Constructors
		
		
	// Methods
}
