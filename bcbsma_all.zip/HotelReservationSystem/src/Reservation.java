import java.time.*;

public class Reservation {
	// Variables
	public int id;
	public LocalDateTime stayStartDate;
	public LocalDateTime stayEndDate;
	public double stayAmountChargedToCustomer;
	public int customerAccountCharged;
	public String confirmationCode;
		
	// Constructors
	public Reservation() {}
	public Reservation(int i, LocalDateTime start, LocalDateTime end, double charge, int account) {
		id = i;
		stayStartDate = start;
		stayEndDate = end;
		stayAmountChargedToCustomer = charge;
		customerAccountCharged = account;
		confirmationCode = MakeConfirmationCode();
	}
			
	// Methods
	public String MakeConfirmationCode()
	{
		String confirmationCodeString;
		
		// Get Code from API
		confirmationCodeString = "949JIE";
		
		// Return Code
		return confirmationCodeString;
	}
}
