
public class ArrayMain {

	public static void main(String[] args) {
		System.out.println("Hello Arrays");
		
		int[] currentInts = Database.FillArray(3);
		
		for (int i = 0; i < currentInts.length; i++)
		{
			System.out.println(currentInts[i]);
		}
		
		// Add an int to the list
		
		// Update the currentInts "storage" area
		
		// Redisplay the Array

	}

}
