import java.util.Random;

public class Database {
	
	// Create an array with x number of values
	public static int[] FillArray(int x) {
		int[] tempArray = new int[x];
		Random rand = new Random();
		
		for (int i=0; i < tempArray.length; i++)
		{
			// Random between 1 and 30
			int randArrayValue = rand.nextInt(29) + 1;
			tempArray[i] = randArrayValue;
		}
		
		return tempArray;
	}
	
	public static int[] UpdateDatabase(int[] currentInts)
	{
		int[] updateTempArray = new int[currentInts.length];
		
		return updateTempArray;
	}

}
