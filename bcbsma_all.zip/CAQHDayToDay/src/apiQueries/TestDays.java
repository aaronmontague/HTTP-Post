package apiQueries;

import java.time.LocalDate;

public class TestDays {

	public static void main(String[] args) {
		
		System.out.println("Begin");
		
		//Set begin date
		LocalDate beginDate = LocalDate.of(2019, 2, 25);

		//Set number of days to add
		int numDays = 7;
		
		for( int i = 1; i < numDays; i++ ) {
			LocalDate endDate = beginDate.plusDays(6);
			System.out.println("Date: " + beginDate.toString() + " - " + endDate);
			beginDate = beginDate.plusDays(1);
		}
		
		System.out.println("End");

	}

} 
