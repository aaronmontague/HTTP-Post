package apiQueries;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Date;

public class DayToDay {
	
	public static void main(String[] args) {
		// Set up the result Strings
		String attestResultsHeader = "Day over Day Results - HTTP Response Code - Valid JSON?" + System.lineSeparator();
		String attestResults = null;
		
		// File to  write results
		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter("C:\\Users\\amonta01\\Desktop\\CAQH_Atest_Dump.txt");
		}
		catch (Exception e) {
			System.out.println(e.toString());
		}
		PrintWriter printWriter = new PrintWriter(fileWriter);
				
		// Add header
		printWriter.write(attestResultsHeader);
				
		// Add a timestamp to the file, exact millisecond is not important
		Date date= new Date();
		Timestamp beginTimeStamp = new Timestamp(date.getTime());
		printWriter.append(beginTimeStamp.toString() + System.lineSeparator());
		
		// Set begin date
		LocalDate beginDate = LocalDate.of(2019, 1, 1);
		
		// Set number of days to add
		int totalQueryDays = 366;
		
		// Run query for each day and get status code
		for( int i = 0; i <= totalQueryDays; i++ ) {
			LocalDate queryDate = beginDate.plusDays(i);
			// Query for the initial day and the range 
			attestResults = queryDate + ":" + System.lineSeparator();
			for (int queryDaySpan = 0; queryDaySpan <= 6; queryDaySpan++) {
				
					try {
						String apiGetResults = AttestationQuery.attestGet(queryDate, queryDate.plusDays(queryDaySpan));
						if (apiGetResults != null) {
							attestResults += apiGetResults + System.lineSeparator();
						}
					} catch (Exception e) {
						// SSL issue inside the firewall, VPN on or off it still fails
						e.printStackTrace();
						attestResults += queryDate + " failed to connect" + System.lineSeparator();
					}
			}
			// Append to .txt file
			printWriter.append(attestResults);
		}
		// Add ending time
		Date dateEnd = new Date();
		Timestamp endTimeStamp = new Timestamp(dateEnd.getTime());
		printWriter.append(endTimeStamp.toString());
		
		// Clean up the printwriter
		printWriter.close();
	}
}
