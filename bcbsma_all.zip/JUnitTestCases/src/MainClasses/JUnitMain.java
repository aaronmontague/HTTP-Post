package MainClasses;

import tests.AddFunctionTests;
import tests.SubtractFunctionTests;

import java.util.ArrayList;
import java.util.List;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class JUnitMain {

	public static void main(String[] args) {
		System.out.println("Hello JUnit World!");
		
		// Grab results of each calc function test
		Result addResult = JUnitCore.runClasses(AddFunctionTests.class);
		Result subtractResult = JUnitCore.runClasses(SubtractFunctionTests.class);
		
		// Create List of Failed Tests
		List<Failure> AllFailures  = new ArrayList<Failure>();
		for (Failure failure : addResult.getFailures()) {
			AllFailures.add(failure);
	    }
		
		for (Failure failure : subtractResult.getFailures()) {
			AllFailures.add(failure);
	    }
		
		// Display success/failures
		if (AllFailures.isEmpty()) {
			System.out.println("All tests passed! Nice work :)");
		}
		else {
			System.out.println("The following tests failed:");
			for (Failure failure : AllFailures) {
				System.out.println(failure);
			}
		}
	}

}
