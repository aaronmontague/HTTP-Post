package classes;

import java.math.BigDecimal;

public class CalcFunction {
	public static BigDecimal Add(BigDecimal x, BigDecimal y)
	{
		return x.add(y);
	}
	
	public static BigDecimal Subtract(BigDecimal x, BigDecimal y)
	{
		return x.subtract(y);
	}
}
