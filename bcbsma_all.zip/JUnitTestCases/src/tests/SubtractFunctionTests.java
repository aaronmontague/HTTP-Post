package tests;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Test;
import classes.CalcFunction;

public class SubtractFunctionTests {
	
	@Test
	public void subtractTwoInts() {
		BigDecimal a = new BigDecimal(10);
		BigDecimal b = new BigDecimal(4);
		BigDecimal c = new BigDecimal(6);
		assertTrue(CalcFunction.Subtract(a, b).compareTo(c) == 0);
	}
	
	@Test
	public void subtractTwoBigDecimals() {
		BigDecimal a = new BigDecimal(12.3);
		BigDecimal b = new BigDecimal(11.2);
		BigDecimal c = new BigDecimal(1.1);
		BigDecimal resultAB = new BigDecimal(0);
		
		// Get calculation
		resultAB = CalcFunction.Subtract(a, b);
		
		// Round the result and set precision for the comparison
		resultAB = resultAB.setScale(10, BigDecimal.ROUND_HALF_UP);
		c = c.setScale(10, BigDecimal.ROUND_HALF_UP);
		
		assertTrue(resultAB.compareTo(c) == 0);
	}
}