package tests;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Test;

import classes.CalcFunction;

public class AddFunctionTests {
	
	@Test
	public void addTwoInts() {
		BigDecimal a = new BigDecimal(11);
		BigDecimal b = new BigDecimal(12);
		BigDecimal c = new BigDecimal(23);
		assertTrue(CalcFunction.Add(a, b).compareTo(c) == 0);	
	}
	
	@Test
	public void addTwoDoubles() {
		BigDecimal a = new BigDecimal(11.3);
		BigDecimal b = new BigDecimal(12.2);
		BigDecimal c = new BigDecimal(23.5);
		assertTrue(CalcFunction.Add(a, b).compareTo(c) == 0);
	}
}