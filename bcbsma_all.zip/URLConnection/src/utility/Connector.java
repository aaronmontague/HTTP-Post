package utility;
// URL Imports
import java.net.MalformedURLException; 
import java.net.URL;

public class Connector {

	public static void main(String[] args) throws MalformedURLException {
		String helloWorld = "Hello World";
		System.out.println(helloWorld);
		
		// URL formation
		try {
			URL printThisURL = getURL();
			System.out.println(printThisURL);
		}
		catch (Exception e) {
			System.out.println(e.toString());
		}

	}
	
	public static URL getURL() throws MalformedURLException 
	{
		String w3Url = "https://www.w3schools.com";
		URL url1 = new URL("https","www.google.com", "");
		URL url2 = new URL(w3Url);
		
		return url1;
	}
}